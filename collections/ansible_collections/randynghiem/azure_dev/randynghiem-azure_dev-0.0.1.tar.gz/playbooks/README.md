# Collection of all playbooks

A container for all playbook artifacts under this folder.