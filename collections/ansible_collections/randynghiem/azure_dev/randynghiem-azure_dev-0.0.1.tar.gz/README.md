# Ansible Collection - randynghiem.azure_dev

Documentation for the collection.

Reference:

* https://www.ansible.com/blog/getting-started-with-ansible-collections
* https://docs.ansible.com/ansible/latest/dev_guide/developing_collections.html
* https://redhatnordicssa.github.io/how-we-test-our-roles
* https://blog.artis3nal.com/2019-11-11-ansible-collection-integration-tests/
